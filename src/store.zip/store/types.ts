export interface PanelShow {
  showSMap: boolean;
  showAMap: boolean;
  showModelo: boolean;
}

export interface CommonState {
  mapType: string;
  panelShow: PanelShow;
  layers: Array<CimiumLayer>;
}

export interface RootState {
  commonState: CommonState;
  panelShow: PanelShow;
}
