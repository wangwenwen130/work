import { Commit, ActionTree, MutationTree } from "vuex";
import { CommonState, RootState } from "../types";
import { Module } from "vuex";

const state: CommonState = {
  mapType: "test1",
  panelShow: {
    showSMap: false,
    showAMap: false,
    showModelo: false
  },
  layers: []
};

const getters = {};

const mutations: MutationTree<CommonState> = {
  setMapType(state: CommonState, mapType: string) {
    state.mapType = mapType;
  },
  showIndex(state: CommonState) {
    state.panelShow.showAMap = true;
    state.panelShow.showSMap = false;
    state.panelShow.showModelo = false;
  },
  updateLayers(state: CommonState, layers: Array<CimiumLayer>) {
    state.layers = [...layers];
  }
};

const actions: ActionTree<CommonState, any> = {
  setMapTypeAction: (context: { commit: Commit }, payload: string) => {
    context.commit("setMapType", payload);
  }
};

const common: Module<CommonState, RootState> = {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
};

export default common;
